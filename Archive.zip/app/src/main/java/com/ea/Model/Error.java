
package com.ea.Model;

@SuppressWarnings("unused")
public class Error {

}
