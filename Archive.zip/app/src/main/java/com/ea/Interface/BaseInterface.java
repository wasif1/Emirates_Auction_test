package com.ea.Interface;

public interface BaseInterface {

}
