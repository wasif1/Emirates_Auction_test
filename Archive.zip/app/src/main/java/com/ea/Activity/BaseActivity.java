package com.ea.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ea.Interface.BaseInterface;


public class BaseActivity extends AppCompatActivity implements BaseInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

}
